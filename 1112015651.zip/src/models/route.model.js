export const routes = {
    inicio: "/",
    dieta: "/dieta",
    materias: "/materias",
    acerca: "/acerca",
};