import { acercaDocs } from "../models/acerca.model.js";

export const getAcercaDocs = () => {

    return acercaDocs;
};